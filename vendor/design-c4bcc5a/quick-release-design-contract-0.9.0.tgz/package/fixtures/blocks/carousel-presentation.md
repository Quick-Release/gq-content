# Saved Carousel producer fixture

Source: `tests/fixtures/carousel-presentation.json`, introduced by
`0be23e8` for issue #78. Its exact `html` string was stored as a published page
in issue #82's owned disposable WordPress 7.0 Site. The active plugin checkout
was `bf709f59ff915db719c1639fe1106476497a5444` (integration through
`f57ae3eb8ece88f72eaba95560576fae6c8e55b0`). PHP was 8.5.10 and
WPGraphQL was 2.23.1.

An anonymous HTTP GET to `/wp-json/wp/v2/pages/{id}` returned the node in
`getquickBlocks[0]`. This fixture wraps that unmodified node in the public
`block-fixtures` envelope. JSON keys are sorted using the existing contract
serializer; no node values, HTML, URLs, defaults or identities are normalized.
The temporary page was deleted after capture.

The response passed the canonical public schema. A real HTTP WPGraphQL query
for the same page's `getquickBlocksJson` returned the same tree. This proves
producer delivery, not a consumer's CSS, layout or interaction behavior.

SHA-256:

- Published `carousel-presentation.json`: `ddb58fb636e28b3da412575775b22a0f73aae30f3afbb5d1728a007a4a7cc6f2`
- Source JSON file: `c6a4a538e525ca0e6764c244a7ffdc5ddaa7f731bff2acd48e28ff93d0b16c6b`
- Exact saved `html` string (UTF-8): `7dd173c951dded0dd589744fa55bdea41228c46fa0eb6add75190e2626263e7d`

`tests/contract/producer.php` reproduces this standalone fixture from the same
saved document. Consumers may import it independently of the combined manifest
and neutral fixture regeneration.

The coordinated candidate was regenerated at source
`3bdacaefae5eb643ba81df03e54b5a646af7cd66` on issue #82's owned WordPress 7.0
installation (PHP 8.5.10). The original producer and immediate repeat fixture
comparison passed. The nested Heading now also carries canonical inline
`attributes.content`; its HTML, slide order and saved source are unchanged.
Anonymous HTTP REST and HTTP WPGraphQL probes on that source returned the same
node as this candidate snapshot, with strict public-schema validation.

Candidate JSON SHA-256: `daa8f94d462d51cb598113c362c7c31c4f1e1550132942248b087fe4cb711778`.
Both source hashes above remain unchanged. This refresh continues to establish
producer delivery rather than consumer appearance or coordinated release acceptance.
