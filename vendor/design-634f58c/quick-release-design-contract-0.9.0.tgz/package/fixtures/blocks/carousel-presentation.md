# Saved Carousel producer fixture

Source: `tests/fixtures/carousel-presentation.json`, introduced by
`0be23e8` for issue #78. Its exact `html` string was stored as a published page
in issue #82's owned disposable WordPress 7.0 Site. The active plugin checkout
was `bf709f59ff915db719c1639fe1106476497a5444` (integration through
`f57ae3eb8ece88f72eaba95560576fae6c8e55b0`). PHP was 8.5.10 and
WPGraphQL was 2.23.1.

An anonymous HTTP GET to `/wp-json/wp/v2/pages/{id}` returned the node in
`getquickBlocks[0]`. This fixture wraps that unmodified node in the public
`block-fixtures` envelope. JSON keys are sorted using the existing contract
serializer; no node values, HTML, URLs, defaults or identities are normalized.
The temporary page was deleted after capture.

The response passed the canonical public schema. A real HTTP WPGraphQL query
for the same page's `getquickBlocksJson` returned the same tree. This proves
producer delivery, not a consumer's CSS, layout or interaction behavior.

SHA-256:

- Published `carousel-presentation.json`: `ddb58fb636e28b3da412575775b22a0f73aae30f3afbb5d1728a007a4a7cc6f2`
- Source JSON file: `c6a4a538e525ca0e6764c244a7ffdc5ddaa7f731bff2acd48e28ff93d0b16c6b`
- Exact saved `html` string (UTF-8): `7dd173c951dded0dd589744fa55bdea41228c46fa0eb6add75190e2626263e7d`

`tests/contract/producer.php` reproduces this standalone fixture from the same
saved document. Consumers may import it independently of the combined manifest
and neutral fixture regeneration.
