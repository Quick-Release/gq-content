# Saved Video Hero documents

`video-hero-saved.json` contains the public `getquickBlocks[0]` nodes from
`GET /wp/v2/pages/{id}` for the two accompanying Gutenberg documents. Import it
through `@quick-release/design-contract/fixtures/blocks/video-hero-saved.json`.

Both HTML inputs were committed at
`4e6f3ddcc157fb16388d97c5bc93f4154b6d401a`. Their published copies retain the
exact bytes from `tests/fixtures/video-hero-{presentation,youtube}.html`:

| Document | SHA-256 |
| --- | --- |
| `video-hero-saved-presentation.html` | `ceb2ddc6360274c5ab97e18836f3755df641fc720a5e2aefe931ff01b9c92239` |
| `video-hero-saved-youtube.html` | `dbdf5b59fb89f673f8f780fbedae4360e60a76a31a6cdfd5461fde2d7440b4f4` |

`tests/video-hero-presentation.test.mjs` exercises the real WordPress block editor
controls and checks its serialized output against these immutable documents.
The presentation document authors foreground alignment, width, height, fit,
colors and a keyboard-accessible link. It has a poster and an empty self-hosted
video source; it does not demonstrate a saved streaming video source. The YouTube
document includes a localized iframe title, source URL, responsive fit and link.
The test reopens it, changes its source and fit controls, restores their values
and verifies the same saved bytes.

The initial node capture ran on the isolated WordPress 7.0 installation at
renderer/plugin source `0477b9fdc1b8cd608048df589851d5b577661f92`, with the
capture additions in this commit. `tests/contract/producer.php` saves each exact
document as a published page using the disposable administrator, asserts stored
source equality, switches to anonymous actor 0, and invokes the registered core
REST route through `rest_do_request`. It retains the returned node without
rewriting values; the fixture writer sorts JSON object keys. Temporary pages
are deleted in the producer's cleanup.

`pnpm contract:fixtures` regenerates the nodes and copies the source documents;
`pnpm test:contract` rejects drift. The fixture is packaged data rather than a
claim that every external Site has passed acceptance. The constructed valid,
empty and invalid media cases in `video-hero-contract.php` remain separate
producer-boundary coverage.

The coordinated candidate was regenerated on issue #82's isolated WordPress 7.0
installation (PHP 8.5.10) at source
`374904aa96fcd6250e1610781c80707ab651258e`, containing the canonical inline
attribute delivery and shared public-read normalization fixes. The original
producer passed unchanged, saving each exact source and reading its registered
REST response. Both paragraph `attributes.content` values retain their inline
links (`#destination` and `#next`); paragraph HTML remains unchanged. Both HTML
SHA-256 values above were verified unchanged. Regenerated JSON SHA-256:
`0fc5b229f2e67658fb2844098bfa56eea3891b658747990d678a399b377a9cc2`. This capture uses the registered REST dispatcher, not an external
HTTP request, and does not claim consumer rendering acceptance.
