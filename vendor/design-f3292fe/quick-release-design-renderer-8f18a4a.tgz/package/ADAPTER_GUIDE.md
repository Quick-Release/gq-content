# Framework adapter guide

An adapter translates the framework-neutral GETQUICK Design contract into one
rendering runtime. Each commerce Site owns its React adapter. The shared renderer has no React dependency.
An adapter uses `@quick-release/design-contract` and
`@quick-release/design-renderer`; it must not read WordPress PHP or another Site's adapter. Render contract data rather than depending on WordPress frontend markup.

## Required responsibilities

### Contract boundary and traversal

Validate API JSON against the published JSON Schema at the network boundary, then
call `assertDesignLayout()` before rendering. Use `renderDesignLayout()` or
`walkDesignLayout()` so every framework observes the same header/content/footer
order, recursive child order, limits, and JSON Pointer paths. Treat `sourceId` as
diagnostic only; logical `template:*` and `part:*` IDs are portable.

### Node registry

Provide an explicit renderer for every block that the manifest marks `enabled`.
CI must call `validateManifestAdapter()` and fail on missing enabled renderers. A
wildcard renderer is suitable for tools and prototypes, but never satisfies
production manifest coverage.

The required `unknownNode` handler must be safe, deterministic, and visible to
telemetry. It must not execute arbitrary markup, scripts, shortcodes, or PHP.
Unknown and `supported: false` nodes should preserve safe child output when
possible, without pretending the missing component rendered successfully.

### Data requirements

Layout JSON includes composition and some resolved presentation data: navigation
items, Query item identities and pattern children, Branding logos, and Social Links
profiles. Consume those documented attributes directly. Query item IDs identify
content to render; they are not permission to expose private content or fetch
arbitrary database records.

Site Logo nodes carry `logo`, `logoVariation` and `logoDark` images or `null`.
Use `selectSiteLogo()` for the light/dark fallback from `logoDark` to `logo` to
the Site Title. It never substitutes `logoVariation`.

Other required route/domain data is supplied through `RendererEnvironment.data`.
Missing contexts produce `getquick_renderer_missing_context`; adapters should
render a bounded error or placeholder and report it without leaking private data.

### Composed core blocks

Grid preserves ordered Container children and desktop/tablet/mobile column counts.
Container sizing supplies `width`, `tabletWidth` and `mobileWidth` as a fraction
(`"1/2"`), `"auto"` or `"full"`, and `alignment`, `tabletAlignment` and
`mobileAlignment` as `"start"`, `"center"` or `"end"`. Desktop values apply on
every device. Tablet values override them below 64rem, and mobile values override
both below 48rem. Empty or absent values inherit. A width is a share of the parent.
Alignment places the container in the reading direction's start, center or end
of its parent, and takes precedence over a constrained parent's centering. Map
these values to the Site's own styling; they are not Tailwind classes.
Carousels preserve ordered Slider children and their separate Carousel Navigation
options. Query Loop keeps the stable `getquick-design/query` name, resolves its
selected items and supplies the item pattern once as children; the Site adapter
owns repeating that pattern with each item's content context. The retired
`getquick-design/loop` marker is unsupported and must remain visible to diagnostics.

Video Hero preserves nested accessible content over a decorative viewport
background. Support self-hosted and YouTube sources, muted looping autoplay and
inline playback, valid poster fallback, and no player when a source is invalid.
Use the serialized URL and media options, including `iframeTitle`, rather than
recovering media from saved HTML. A Site owns media loading, reduced-motion and
presentation behavior.

Social Links supplies the complete `attributes.links` list. No extra GraphQL
request is needed. Preserve order and accessible labels, use a custom icon URL
when present and the supplied SVG fallback otherwise, and render nothing for an
empty list. Custom icon images have empty alternative text; the link supplies its
accessible name. Validate URLs and treat SVG as data requiring an appropriate safe
rendering boundary. Preserve the block's native wrapper/style options.

### Tokens

Resolve semantic token/value pairs through `resolveToken`; the shared
`resolveDesignToken` handles WordPress preset references and dotted token names. Each platform owns its
mapping to CSS variables, native styles, design-system values, or another styling
mechanism. Never expose Tailwind classes, React props, or platform component names
in the public contract. Unknown tokens must degrade to an explicit safe default.

### Links

Blocks with link-like attributes must call the environment's `resolveLink` boundary.
The adapter owns URL policy, locale-aware internal routing, external-link behavior,
targets, rel values, and navigation APIs. Never pass an unvalidated contract string
directly to a navigation primitive.

### Language and direction

Use `layout.language.resolved` for the rendered language and
`layout.language.direction` for `ltr`/`rtl`. Preserve the requested/resolved fallback
state for diagnostics. Canonical and alternate URLs come from API response `Link`
headers or the route loader, not from WordPress implementation IDs.

### Errors and diagnostics

`RendererContractError` means the response cannot be safely traversed and must stop
rendering at the route boundary. `RenderIssue` describes a recoverable adapter,
manifest, unknown-node, or missing-context condition. Send issues through
`onIssue`, then let framework-specific error boundaries decide presentation.
Correlation and observability transport remain outside renderer core.

## Minimal non-React adapter

```ts
const adapter = {
  nodes: {
    "core/paragraph": ({ node }) => ({ kind: "text", value: node.content }),
  },
  unknownNode: ({ node, children }) => ({
    kind: "unknown",
    name: node.name,
    children,
  }),
  region: ({ region, children }) => ({
    kind: "region",
    slot: region.slot,
    children,
  }),
  layout: ({ layout, regions }) => ({
    kind: "layout",
    language: layout.language.resolved,
    children: regions,
  }),
};

const tree = renderDesignLayout(layout, adapter, {
  context: {},
  data: { site },
  resolveToken: (token, value) => tokenMap[token]?.[value],
  resolveLink: (value) => safeUrl(value),
  onIssue: (issue) => report(issue),
});
```

The returned value can be consumed by Vue, Svelte, native mobile, a server-side
template engine, a static generator, or a test harness without changing WordPress
serialization.

## Reference scope

`@quick-release/design-renderer/reference` exports `renderReferenceHtml` and its
explicit `referenceAdapter` registry. It produces escaped diagnostic metadata and
children, not a storefront UI. Its contract-fixture tests do not prove a Site's grid
breakpoints, video behavior, social presentation, Query repetition or carousel
interaction. Verify those in the Site-owned adapter.

## Run the pinned contract in Site CI

Import `assertRegistryCoverage` and `assertFixtureRendering` from
`@quick-release/design-renderer/testing`. Both work with any test runner and throw
`RendererTestError` containing actionable failures. Keep the contract and renderer
packages pinned together.

```ts
assertRegistryCoverage(adapter, { siteBlocks: siteManifestAdditions });
assertFixtureRendering(
  adapter,
  {
    context: adapterFixtureContext,
    data: routeFixtureData,
    resolveToken: resolveDesignToken,
    resolveLink: safeFixtureLink,
    onIssue: reportFixtureIssue,
  },
  {
    siteBlocks: siteManifestAdditions,
    additionalFixtures: siteFixtures,
  },
);
```

Supply only Site-added manifest entries (`name` and `enabled`) rather than a copy
of the core manifest. They append required enabled names without changing core
requirements. Extra registry names are allowed; a wildcard does not satisfy
coverage. All producer-neutral fixture variants always run. Additional Site
fixtures append `{ fixture, node }` cases and should exercise composed children and
Site-specific data requirements. Provide the domain contexts and resolvers your
adapter actually needs; missing data, fallback and exceptions fail the check.

Each fixture runs in an isolated content region with otherwise empty regions, so
these are portable block checks rather than route-specific integration fixtures.
Reported failures include the fixture identifier and JSON Pointer. Add Site tests
for route behavior, loading, repetition, accessibility and interaction.
