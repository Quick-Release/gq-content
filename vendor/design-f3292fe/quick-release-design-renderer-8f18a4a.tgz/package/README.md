# @quick-release/design-renderer

Framework-neutral traversal and validation for GQ Design layouts. The package
ships at the plugin and contract package's version. Each commerce Site owns its
React adapter; this package has no React, browser, or Node runtime dependency.

```ts
import {
  renderDesignLayout,
  resolveDesignToken,
  validateManifestAdapter,
  type RendererAdapter,
} from "@quick-release/design-renderer";
```

The root exports `renderDesignLayout`, `walkDesignLayout`, `assertDesignLayout`,
`inspectNode`, `validateManifestAdapter`, `RendererContractError`,
`resolveDesignToken`, `selectSiteLogo`, `presetStyles`, `presetStyleText`, `presetSchemeStyles`,
`presetStyleSheet`, `isPresetColorValue`, `isDarkCounterpartValue`,
`isPresetColorProperty` and adapter/environment/issue/preset types. The renderer is generic
over adapter output and never creates markup. Supply an environment with the
Site context, required external data, link policy, token resolver and issue handler.
Use `validateManifestAdapter(manifest, adapter)` to report every enabled block
without an explicit renderer; a wildcard does not satisfy this coverage check.

`resolveDesignToken(token, value)` can be passed directly as `resolveToken`. It
maps `var:preset|color|primary` to `var(--wp--preset--color--primary)`, nested preset
segments to further `--` segments, and `color.accent` to `var(--gqd-color-accent)`.
It returns an empty string for other or hostile values. It does not provide palette
values; `presetStyles` defines the variables it refers to.

`selectSiteLogo(node.attributes, scheme)` applies the documented Site Logo fallbacks
for a `"light"` or `"dark"` surface. Dark surfaces use `logoDark`, then `logo`; light
surfaces use `logo`; otherwise it returns `source: "siteTitle"`. A missing,
unusable or non-HTTP(S) image counts as unavailable. `reviewLegibility` is `true`
when the primary logo stands in on a dark surface. `logoVariation` is never a
fallback. The Site still decides which scheme a surface uses.

## Preset styles

```ts
import { presetStyles, presetStyleText } from "@quick-release/design-renderer";

const tokens = await client.getTokens();
presetStyles(tokens); // { "--wp--preset--color--accent": "#2563eb", ... }
presetStyleText(tokens); // "--wp--preset--color--accent: #2563eb; ..."
```

`presetStyles(tokens, { onIssue })` returns the palette's custom-property
declarations as a record, in palette order, for any output: a `:root` rule, a
style attribute or a framework's style object. `presetStyleText` joins the same
declarations as text. Property names come from each colour's `cssVariable`, which
is how WordPress spells the variable (slug `accent1` becomes `accent-1`).

Validation is strict. An entry is skipped, and reported once through `onIssue`
with code `getquick_renderer_unsafe_preset` and a JSON Pointer `path`, when its
slug has characters other than letters, digits, `-` and `_`; its property is not
`--wp--preset--color--<kebab-case>`; or its value is not a literal colour: a hex
colour, a colour keyword (not a CSS-wide keyword), or one unnested `rgb()`,
`hsl()`, `hwb()`, `lab()`, `lch()`, `oklab()`, `oklch()` or `color()` call with
plain arguments, at most 128 characters. `var()`, `url()`, `calc()`,
`color-mix()` and `light-dark()` values are rejected. `isPresetColorValue` and
`isPresetColorProperty` expose the same checks. When two entries define the same
property, the later wins, as in WordPress's stylesheet, and the duplicate is
reported. A malformed document yields no declarations; a throwing `onIssue` is
ignored.

### Light and dark schemes

```ts
import { presetSchemeStyles, presetStyleSheet } from "@quick-release/design-renderer";

presetStyleSheet(tokens);
// :root { color-scheme: light; --wp--preset--color--foreground: #111111; ... }
// @supports (color: light-dark(#000, #fff)) { :root { color-scheme: light dark;
//   --wp--preset--color--foreground: light-dark(#111111, #f5f5f5); } }
presetSchemeStyles(tokens); // { enabled, light: {...}, dark: {...} }
```

`presetStyleSheet(tokens, { onIssue })` returns a stylesheet for the document
root. Load it after WordPress's own preset variables. Its first rule always
declares the light colours, with `color-scheme: light`. Only when the tokens
have `darkSchemeEnabled: true` does a second rule follow. It is guarded by a
colour-form `light-dark()` feature query. It sets `color-scheme: light dark`, so
the page follows the reader's system preference. It also redeclares each colour
whose dark value differs from its light value as `light-dark(<light>, <dark>)`.
The stylesheet is composed from `presetSchemeStyles` and written by the same
declaration emitter as `presetStyleText`.

- Browsers without colour `light-dark()` ignore the guarded rule and stay light.
- A colour without a counterpart (`darkColor: null` or absent) keeps its light
  value in both schemes.
- Disabled or unconfigured support yields the light rule alone, so the page and
  its native controls stay light.

Existing preset classes (`.has-accent-color`) and preset references resolved by
`resolveDesignToken` read these variables, so they follow the scheme. Literal
authored colours do not change.

The Site owns the scheme choice. To force one, set `color-scheme: light` or
`dark` with a more specific selector than `:root`, such as
`:root[data-scheme="dark"]`. An element with its own `color-scheme` (for
example `color-scheme: light` on an intentionally light panel) resolves the same
variables for that scheme.

The colour query proves nothing about the image form of `light-dark()`, and
this utility never emits it. Choose images, such as logos, with
`selectSiteLogo` and the Site's own scheme state.

`presetSchemeStyles` returns the same validated values as records:

- `light` is identical to `presetStyles`.
- `dark` lists every light property, with the authored counterpart or the
  inherited light value. Use it, for example, to apply a forced dark preview
  without `light-dark()`.
- `enabled` is true only for a boolean `true` flag.

Both functions apply `presetStyles`' validation. A `darkColor` must match the
contract: a `#rgb` or `#rrggbb` hex colour, which `isDarkCounterpartValue`
checks. That is narrower than a light value, so a host that skips the client
validator still renders no dark value the Site's contrast checks could not
evaluate. Any other `darkColor` is reported at `/colors/<n>/darkColor` and the
colour inherits its light value. A light entry that fails validation is skipped together with
its counterpart. A non-boolean `darkSchemeEnabled` is reported and treated as
disabled. No other token text reaches the CSS.

## Diagnostic reference output

```ts
import { referenceAdapter, renderReferenceHtml } from "@quick-release/design-renderer/reference";
```

The reference adapter explicitly recognizes the supported core blocks. Its
escaped `<gqd-node>` output exposes attributes, resolved tokens, content and nested
children for inspection. It renders unsupported or unrecognized blocks as
`<gqd-unknown>`. It does not implement responsive layouts, video players, social
icons, carousels, or repeated Query presentation. Passing its coverage tests proves
contract traversal and data preservation; each Site must verify its actual UI.

See [ADAPTER_GUIDE.md](ADAPTER_GUIDE.md) for production adapter responsibilities.
Run `pnpm --filter @quick-release/design-renderer check` to compile declarations,
check framework boundaries and test the built exports against the contract's
exported producer fixtures. `pnpm typecheck` checks the runtime against ES2022
without DOM or Node ambient types. Build output is generated in `dist/` and is
excluded from plugin archives.

## REST client

```ts
import {
  createDesignClient,
  DesignApiError,
  DesignContractError,
} from "@quick-release/design-renderer/client";

const client = createDesignClient({
  baseUrl: "https://cms.example/wp-json/getquick-design/v1",
  fetch: requestFetch,
  adapter: siteAdapter,
  onIssue: reportIssue,
});
// Call explicitly at startup when runtime coverage reporting is wanted.
const manifest = await client.getManifest();
const { layout, links } = await client.getLayout("single-post", { language: "fr" });
const discovery = await client.getDiscovery();
const tokens = await client.getTokens(); // contract 1.1.0 and later
const { icons } = await client.getIcons(); // contract 1.2.0 and later
const preview = await client.createPreview({
  templateKey: "single-post",
  revisionId: 42,
  nonce: wordpressNonce,
  language: "fr",
});
const unpublished = await client.getPreview(preview.token, { nonce: wordpressNonce });
```

`fetch` and the API namespace URL are required. There are no environment defaults,
implicit manifest requests, global transport calls, React, DOM or Node runtime
imports. `FetchLike`, `DesignRequestInit` and `DesignResponse` are structural
interfaces compatible with standard fetch implementations. Preview calls send
`X-WP-Nonce` and default to `credentials: "include"`; callers can override the
credentials policy. Layout resources preserve their validated body and return
parsed `Link` header entries as `{href, rel, hreflang?}`, independent of parameter
order and quoted commas. Missing/malformed link entries are ignored.

Every JSON response is validated. Valid non-success problems throw
`DesignApiError`, carrying `status`, `code`, `endpoint` and the complete validated
`problem`. Invalid JSON, incompatible bodies and invalid problems throw
`DesignContractError`, carrying `status`, `endpoint` and validation `issues`.
Problem status must match HTTP status. Network failures propagate unchanged.
The client performs no automatic retry or conditional-cache requests.

Consumer validators accept additive fields at every object boundary and compatible
`1.x` contract versions, retaining required properties, field types, enum values
and other schema constraints. Strict producer schemas remain unchanged. Layout
and preview validation first applies the renderer's depth (64) and node-count
(5,000) limits before recursive schema checks. `assertDesignLayout` preserves
those limits and accepts the same compatible major version.

`getManifest()` compares the live manifest with an optional adapter and reports
both missing enabled renderers and unlisted adapter entries through `onIssue`.
Explicit child names declared in `allowedChildren` count as listed; wildcard
renderers do not satisfy required coverage. These are advisory runtime reports;
even a throwing issue callback cannot reject an otherwise valid response.
`validateManifestAdapter()` also exposes these reports directly. CI coverage
helpers should fail missing required names, while treating unlisted names as
advisory.

The build derives independent consumer schema copies and compiles standalone Ajv
validators, bundling required helpers into portable ESM. Ajv, its compiler and
esbuild are build dependencies only; exported runtime code executes no `require`,
`eval` or `new Function`. Boundary checks inspect source and built artifacts.

## Site CI checks

`@quick-release/design-renderer/testing` exports runner-neutral assertions. They
throw `RendererTestError` with a `failures` list and a message naming missing
blocks or the failing fixture and node path. Use them from any test runner:

```ts
import {
  assertRegistryCoverage,
  assertFixtureRendering,
} from "@quick-release/design-renderer/testing";

assertRegistryCoverage(siteAdapter, { siteBlocks });
assertFixtureRendering(siteAdapter, siteFixtureEnvironment, {
  siteBlocks,
  additionalFixtures: siteBlockFixtures,
});
```

`siteBlocks` contains only Site additions, each with `name` and `enabled`, from
its `getquick_design_block_definitions` configuration. Core entries come from the
pinned contract manifest and cannot be overridden or disabled by this option.
An explicit renderer is required for every enabled core and supplied Site block;
wildcards do not count. Optional registry entries are allowed.

Fixture rendering always runs **every** neutral block fixture exported by the
pinned contract, including media/profile variants. `additionalFixtures` appends
Site fixtures shaped as `{ fixture, node }`; an empty list cannot replace the core
suite. Each fixture renders in its own synthetic content region with empty header
and footer regions. Site fixtures may contain nested children. The helper catches
contract/adapter errors, emitted issues, and unknown-node fallback, including
registry entries aliased directly to the unknown handler.

Supply realistic Site adapter test data through `siteFixtureEnvironment.context`
and `.data`, plus any token/link resolvers or issue handler the adapter needs.
The helper forwards these options and does not invent missing data contexts.
Coverage returns `{ checkedBlocks }`; successful fixture rendering returns
`{ renderedFixtures }`. These checks prove registry coverage and fixture traversal;
Site UI tests still verify actual presentation and interactions.
