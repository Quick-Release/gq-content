/* Generated from JSON Schema by `pnpm generate`. Do not edit manually. */

export type GetQuickDesignContract =
  | RendererBlockFixtures
  | DesignDiscovery
  | DesignLayout
  | DesignManifest
  | DesignPattern
  | DesignPreviewResponse
  | DesignPreviewToken
  | DesignProblem
  | DesignTokens
  | DesignIcons;
export type DesignNode = {
  name: string;
  attributes: {
    presentation?: DesignPresentation;
    [k: string]: unknown;
  };
  content: string | null;
  children: DesignNode[];
  dataRequirements?: (
    | "site"
    | "post"
    | "product"
    | "productCollection"
    | "productCollections"
    | "cart"
    | "checkout"
    | "navigation"
  )[];
  /**
   * Product collection lookup metadata; product records are fetched separately. Key-only requests retain New Arrivals semantics. Query requests are bounded, and empty selections require empty: true.
   */
  dataRequest?:
    | {
        kind: "productCollection";
        key: string;
        query?: never;
        empty?: never;
      }
    | {
        kind: "productCollection";
        key: string;
        query:
          | {
              /**
               * @minItems 1
               * @maxItems 24
               */
              productIds: [number, ...number[]];
              perPage: number;
            }
          | {
              categoryId: number;
              perPage: number;
            };
        empty?: false;
      }
    | {
        kind: "productCollection";
        key: string;
        query:
          | {
              /**
               * @maxItems 0
               */
              productIds: [];
              perPage: number;
            }
          | {
              categoryId: null;
              perPage: number;
            };
        empty: true;
      };
  tokens?: {
    [k: string]: string;
  };
  supported?: boolean;
};

export interface RendererBlockFixtures {
  renderer: string;
  /**
   * @minItems 1
   */
  blocks: [
    {
      fixture: string;
      node: DesignNode;
    },
    ...{
      fixture: string;
      node: DesignNode;
    }[],
  ];
}
export interface DesignPresentation {
  base?: {
    width?:
      | "reset"
      | "auto"
      | "full"
      | "screen"
      | "1/2"
      | "1/3"
      | "2/3"
      | "1/4"
      | "2/4"
      | "3/4"
      | "1/5"
      | "2/5"
      | "3/5"
      | "4/5"
      | "1/6"
      | "2/6"
      | "3/6"
      | "4/6"
      | "5/6"
      | "1/12"
      | "2/12"
      | "3/12"
      | "4/12"
      | "5/12"
      | "6/12"
      | "7/12"
      | "8/12"
      | "9/12"
      | "10/12"
      | "11/12"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px";
    maxWidth?:
      | "reset"
      | "container"
      | "none"
      | "full"
      | "3xs"
      | "2xs"
      | "xs"
      | "sm"
      | "md"
      | "lg"
      | "xl"
      | "2xl"
      | "3xl"
      | "4xl"
      | "5xl"
      | "6xl"
      | "7xl";
    paddingBlock?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px";
    paddingInline?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px";
    marginBlock?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px"
      | "auto";
    marginInline?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px"
      | "auto";
  };
  sm?: {
    width?:
      | "reset"
      | "auto"
      | "full"
      | "screen"
      | "1/2"
      | "1/3"
      | "2/3"
      | "1/4"
      | "2/4"
      | "3/4"
      | "1/5"
      | "2/5"
      | "3/5"
      | "4/5"
      | "1/6"
      | "2/6"
      | "3/6"
      | "4/6"
      | "5/6"
      | "1/12"
      | "2/12"
      | "3/12"
      | "4/12"
      | "5/12"
      | "6/12"
      | "7/12"
      | "8/12"
      | "9/12"
      | "10/12"
      | "11/12"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px";
    maxWidth?:
      | "reset"
      | "container"
      | "none"
      | "full"
      | "3xs"
      | "2xs"
      | "xs"
      | "sm"
      | "md"
      | "lg"
      | "xl"
      | "2xl"
      | "3xl"
      | "4xl"
      | "5xl"
      | "6xl"
      | "7xl";
    paddingBlock?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px";
    paddingInline?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px";
    marginBlock?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px"
      | "auto";
    marginInline?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px"
      | "auto";
  };
  md?: {
    width?:
      | "reset"
      | "auto"
      | "full"
      | "screen"
      | "1/2"
      | "1/3"
      | "2/3"
      | "1/4"
      | "2/4"
      | "3/4"
      | "1/5"
      | "2/5"
      | "3/5"
      | "4/5"
      | "1/6"
      | "2/6"
      | "3/6"
      | "4/6"
      | "5/6"
      | "1/12"
      | "2/12"
      | "3/12"
      | "4/12"
      | "5/12"
      | "6/12"
      | "7/12"
      | "8/12"
      | "9/12"
      | "10/12"
      | "11/12"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px";
    maxWidth?:
      | "reset"
      | "container"
      | "none"
      | "full"
      | "3xs"
      | "2xs"
      | "xs"
      | "sm"
      | "md"
      | "lg"
      | "xl"
      | "2xl"
      | "3xl"
      | "4xl"
      | "5xl"
      | "6xl"
      | "7xl";
    paddingBlock?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px";
    paddingInline?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px";
    marginBlock?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px"
      | "auto";
    marginInline?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px"
      | "auto";
  };
  lg?: {
    width?:
      | "reset"
      | "auto"
      | "full"
      | "screen"
      | "1/2"
      | "1/3"
      | "2/3"
      | "1/4"
      | "2/4"
      | "3/4"
      | "1/5"
      | "2/5"
      | "3/5"
      | "4/5"
      | "1/6"
      | "2/6"
      | "3/6"
      | "4/6"
      | "5/6"
      | "1/12"
      | "2/12"
      | "3/12"
      | "4/12"
      | "5/12"
      | "6/12"
      | "7/12"
      | "8/12"
      | "9/12"
      | "10/12"
      | "11/12"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px";
    maxWidth?:
      | "reset"
      | "container"
      | "none"
      | "full"
      | "3xs"
      | "2xs"
      | "xs"
      | "sm"
      | "md"
      | "lg"
      | "xl"
      | "2xl"
      | "3xl"
      | "4xl"
      | "5xl"
      | "6xl"
      | "7xl";
    paddingBlock?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px";
    paddingInline?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px";
    marginBlock?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px"
      | "auto";
    marginInline?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px"
      | "auto";
  };
  xl?: {
    width?:
      | "reset"
      | "auto"
      | "full"
      | "screen"
      | "1/2"
      | "1/3"
      | "2/3"
      | "1/4"
      | "2/4"
      | "3/4"
      | "1/5"
      | "2/5"
      | "3/5"
      | "4/5"
      | "1/6"
      | "2/6"
      | "3/6"
      | "4/6"
      | "5/6"
      | "1/12"
      | "2/12"
      | "3/12"
      | "4/12"
      | "5/12"
      | "6/12"
      | "7/12"
      | "8/12"
      | "9/12"
      | "10/12"
      | "11/12"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px";
    maxWidth?:
      | "reset"
      | "container"
      | "none"
      | "full"
      | "3xs"
      | "2xs"
      | "xs"
      | "sm"
      | "md"
      | "lg"
      | "xl"
      | "2xl"
      | "3xl"
      | "4xl"
      | "5xl"
      | "6xl"
      | "7xl";
    paddingBlock?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px";
    paddingInline?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px";
    marginBlock?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px"
      | "auto";
    marginInline?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px"
      | "auto";
  };
  "2xl"?: {
    width?:
      | "reset"
      | "auto"
      | "full"
      | "screen"
      | "1/2"
      | "1/3"
      | "2/3"
      | "1/4"
      | "2/4"
      | "3/4"
      | "1/5"
      | "2/5"
      | "3/5"
      | "4/5"
      | "1/6"
      | "2/6"
      | "3/6"
      | "4/6"
      | "5/6"
      | "1/12"
      | "2/12"
      | "3/12"
      | "4/12"
      | "5/12"
      | "6/12"
      | "7/12"
      | "8/12"
      | "9/12"
      | "10/12"
      | "11/12"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px";
    maxWidth?:
      | "reset"
      | "container"
      | "none"
      | "full"
      | "3xs"
      | "2xs"
      | "xs"
      | "sm"
      | "md"
      | "lg"
      | "xl"
      | "2xl"
      | "3xl"
      | "4xl"
      | "5xl"
      | "6xl"
      | "7xl";
    paddingBlock?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px";
    paddingInline?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px";
    marginBlock?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px"
      | "auto";
    marginInline?:
      | "reset"
      | 0
      | 0.5
      | 1
      | 1.5
      | 2
      | 2.5
      | 3
      | 3.5
      | 4
      | 5
      | 6
      | 7
      | 8
      | 9
      | 10
      | 11
      | 12
      | 14
      | 16
      | 20
      | 24
      | 28
      | 32
      | 36
      | 40
      | 44
      | 48
      | 52
      | 56
      | 60
      | 64
      | 72
      | 80
      | 96
      | "px"
      | "auto";
  };
}
export interface DesignDiscovery {
  contractVersion: "1.3.0";
  schemaVersion: 1;
  namespace: "getquick-design/v1";
  endpoints: {
    manifest: string;
    layoutTemplate: string;
    createPreview: string;
    /**
     * Since contract 1.1.0.
     */
    tokens?: string;
    /**
     * Since contract 1.2.0.
     */
    icons?: string;
  };
}
export interface DesignLayout {
  contractVersion: "1.3.0";
  schemaVersion: 1;
  template: {
    key: string;
    id: string;
    sourceId: string;
    modified: string | null;
  };
  language: DesignLanguage;
  /**
   * @minItems 3
   * @maxItems 3
   */
  regions: [
    {
      slot: "header" | "content" | "footer";
      part: {
        id: string;
        sourceId: string;
        slug: string;
        modified: string | null;
        missing?: boolean;
        language: {
          resolved: string;
          fallback: boolean;
        };
      };
      blocks: DesignNode[];
    },
    {
      slot: "header" | "content" | "footer";
      part: {
        id: string;
        sourceId: string;
        slug: string;
        modified: string | null;
        missing?: boolean;
        language: {
          resolved: string;
          fallback: boolean;
        };
      };
      blocks: DesignNode[];
    },
    {
      slot: "header" | "content" | "footer";
      part: {
        id: string;
        sourceId: string;
        slug: string;
        modified: string | null;
        missing?: boolean;
        language: {
          resolved: string;
          fallback: boolean;
        };
      };
      blocks: DesignNode[];
    },
  ];
  diagnostics?: DesignDiagnostic[];
  dependencies?: DesignDependencies;
}
export interface DesignLanguage {
  requested: string;
  resolved: string;
  locale: string;
  direction: "ltr" | "rtl";
  fallback: boolean;
}
export interface DesignDiagnostic {
  code: string;
  severity: "info" | "warning";
  path: string;
  sourceId?: string;
}
export interface DesignDependencies {
  templates: string[];
  templateParts: string[];
  reusableBlocks: number[];
  navigation: number[];
  /**
   * The layout contains a native dynamic page list and depends on published pages.
   */
  pageList?: boolean;
}
export interface DesignManifest {
  contractVersion: "1.3.0";
  schemaVersion: 1;
  templates: {
    key: string;
    /**
     * @minItems 3
     * @maxItems 3
     */
    regions: [
      "header" | "content" | "footer",
      "header" | "content" | "footer",
      "header" | "content" | "footer",
    ];
  }[];
  blocks: {
    name: string;
    source: "core" | "getquick-design" | "woocommerce" | "polylang" | "site";
    regions: ("header" | "content" | "footer")[];
    dataRequirements: (
      "site" | "post" | "product" | "productCollection" | "cart" | "checkout" | "navigation"
    )[];
    attributes: {
      [k: string]: "string" | "number" | "integer" | "boolean" | "object" | "array";
    };
    tokens: ("spacing" | "color" | "typography" | "radius" | "layout")[];
    allowedChildren: string[];
    rendererFixture: string | null;
    available: boolean;
    enabled: boolean;
    supports?: {
      [k: string]: unknown;
    };
  }[];
  languages: {
    provider: "wordpress" | "polylang";
    active: DesignLanguage[];
  };
  cache: CacheMetadata;
}
export interface CacheMetadata {
  visibility: "public";
  maxAge: number;
  sharedMaxAge: number;
  staleWhileRevalidate: number;
  etag?: string;
  lastModified?: string | null;
}
export interface DesignPattern {
  id: string;
  sourceId: string | null;
  syncMode: "unsynced" | "synced";
  language: string;
  translations: {
    [k: string]: string;
  };
  blocks: DesignNode[];
}
export interface DesignPreviewResponse {
  layout: DesignLayout;
  preview: {
    revisionId: number;
    expiresAt: string;
  };
}
export interface DesignPreviewToken {
  token: string;
  url: string;
  revisionId: number;
  expiresAt: string;
}
export interface DesignProblem {
  type: string;
  title: string;
  status: number;
  code: string;
  detail?: string;
  correlationId?: string;
}
/**
 * The site's preset design tokens, from WordPress's merged global settings, with authored dark counterparts and the dark scheme enablement flag. Since contract 1.1.0. Review state is administrative and never included.
 */
export interface DesignTokens {
  contractVersion: "1.3.0";
  schemaVersion: 1;
  /**
   * Whether the Site enabled its reviewed dark scheme. False when unconfigured. When false, consumers render the light colours only, whatever darkColor values exist.
   */
  darkSchemeEnabled: boolean;
  /**
   * Every colour of the site palette: the theme colours with the saved Global Styles applied, then Site Editor custom colours. A slug is listed once.
   */
  colors: DesignColor[];
}
export interface DesignColor {
  /**
   * Stable palette identity, such as accent.
   */
  slug: string;
  /**
   * Human-readable name.
   */
  name: string;
  /**
   * CSS colour value as authored, such as #2563eb.
   */
  color: string;
  /**
   * The custom property WordPress defines for the colour, such as --wp--preset--color--accent.
   */
  cssVariable: string;
  /**
   * The authored dark counterpart of the colour as a literal hex colour (#rgb or #rrggbb), such as #93c5fd, or null when none is authored: the dark scheme then inherits color. An explicitly identical counterpart is present, not null.
   */
  darkColor: string | null;
}
/**
 * The Site's icons set on GETQUICK → Design → Assets → Icons: the standard slots that are set, in their order, then custom icons in the order they were added. Unset slots are absent. Since contract 1.2.0.
 */
export interface DesignIcons {
  contractVersion: "1.3.0";
  schemaVersion: 1;
  /**
   * @maxItems 101
   */
  icons: DesignIcon[];
}
export interface DesignIcon {
  /**
   * The slot, such as phone, favicon or cart, or a custom icon's slug made from its name. Lowercase words joined by hyphens. A slug is listed once.
   */
  slug: string;
  /**
   * Human-readable name for authors. Not alt text.
   */
  label: string;
  /**
   * Whether an author added the icon rather than it filling a standard slot.
   */
  custom: boolean;
  image: DesignIconImage;
}
/**
 * The icon's media library image, shaped like a resolved logo image.
 */
export interface DesignIconImage {
  id: number;
  url: string;
  /**
   * The attachment's alt text, possibly empty: unlike a logo's, it never falls back to the site title. Treat an empty alt as a decorative icon.
   */
  alt: string;
  width: number | null;
  height: number | null;
  mimeType: string;
}

export interface ResolvedSocialLink {
  service:
    | "instagram"
    | "facebook"
    | "linkedin"
    | "pinterest"
    | "youtube"
    | "tiktok"
    | "x"
    | "bluesky"
    | "threads"
    | "mastodon";
  label: string;
  url: string;
  iconUrl: string | null;
  iconSvg: string;
}

/**
 * A Branding logo image resolved from the media library when the layout is built.
 */
export interface ResolvedLogoImage {
  id: number;
  url: string;
  /**
   * The attachment's alt text, or the plain-text site title when that is empty.
   */
  alt: string;
  width: number | null;
  height: number | null;
  mimeType: string;
}
