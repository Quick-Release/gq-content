# @quick-release/design-contract

The framework-neutral contract owned by GQ Design. This pnpm workspace package
is **private on GitHub Packages**. Its package version matches the plugin version;
publication and release automation run from the same tag as the plugin and
renderer. See the repository README for authentication and release instructions.
Ekis keeps its existing copy
until the first lockstep release, per gq-site ADR 0018.

JSON Schema Draft 2020-12 and OpenAPI 3.1 describe layouts, manifest, discovery,
preset design tokens, Site icons, previews and problem responses. TypeScript declarations are generated from the
schemas and must never be edited by hand. There is no runtime JavaScript entry
point and no framework dependency.

Exports:

- `.`: generated TypeScript declarations, including `DesignLayout`, `DesignNode`,
  `DesignManifest`, `DesignDiscovery`, `DesignTokens`, `DesignColor`,
  `DesignIcons`, `DesignIcon`, `DesignIconImage`,
  `DesignPreviewResponse`, `DesignPreviewToken`, `ResolvedSocialLink` and
  `ResolvedLogoImage`.
- `./schemas/*`: JSON Schemas, including the trimmed `contract.schema.json`
  umbrella for the retained documents.
- `./fixtures/*`: canonical REST examples and documented provider request examples.
- `./openapi`: the seven layout, manifest, discovery, tokens, icons and preview operations.
- `./compatibility.json`: wire contract version, schema version and platform matrix.

For example, `import type { DesignLayout } from "@quick-release/design-contract"`
and `import manifestSchema from "@quick-release/design-contract/schemas/manifest.schema.json"`.

## Version and validation policy

Candidate package **0.9.0** carries **wire contract 2.0.0**. Producer schemas and
fixtures identify that exact wire version; the renderer accepts additive 2.x
responses and rejects 1.x documents. Storage/export envelope integers remain 1.
See [breaking adoption](../../docs/tailwind-breaking-adoption.md); the historical
1.x additions below describe earlier releases, not a compatibility fallback.

`GetQuick\Design\Contract::VERSION` in `src/Contract.php` is the wire version's
single runtime source. It also identifies the contract carried by portability
exports and recorded when initializing design storage. Export format `version`
and stored schema `version` remain separate integers. No workspace files are
needed by the shipped PHP plugin. Tests compare this value with compatibility
metadata, schema constants, OpenAPI and REST output. A package release version is
independent of the wire version; a breaking wire change requires a new wire major,
and an additive one a new minor. Portability imports accept packages exported under
the current or an earlier minor of the same major.

Contract 1.1.0 added `GET /tokens` (`tokens.schema.json`): the public preset palette
as `colors` of `{slug, name, color, cssVariable}`, the same list as WPGraphQL's
`designTokens.colors`. Discovery advertises it as the optional `endpoints.tokens`,
so the original 1.x clients accepted a 1.0.0 discovery document (the 1.1.0 schema itself
pins `contractVersion` to 1.1.0).
Within the same unreleased 1.1.0, the tokens also carry `darkSchemeEnabled`
and each colour's `darkColor` (the authored dark counterpart as `#rgb` or
`#rrggbb`, or null to inherit `color`). Both are required in 1.1.0 documents.

Contract 1.2.0 added `GET /icons` (`icons.schema.json`): the Site icons set on
GETQUICK → Design → Assets → Icons, as `icons` of `{slug, label, custom, image}`,
where `image` has a resolved logo's shape but its `alt` never falls back to the
site title. Discovery advertises it as the optional `endpoints.icons`, so
the original 1.x clients accepted 1.0.0 and 1.1.0 discovery documents.

Producer validation is strict: unknown response properties fail, because an
undocumented field is a contract change. Open-ended attribute/support maps retain
their documented extension points. Client-side compatibility behavior belongs to
the renderer's future `./client` entry point.

`compatibility.json` retains `contractVersion`, `schemaVersion` and `platforms`.
Renderer application versions and block coverage do not belong in that matrix:
releases are lockstep and adapter coverage belongs to the renderer's `./testing`.
The matrix is inherited platform metadata, not a claim that this ticket tested
all listed platform versions.

## Fixtures and scope

From the repository root, with the disposable test site configured:

- `pnpm contract:fixtures`: regenerate fixtures from registered REST routes.
- `pnpm test:contract`: validate unmodified REST responses, then fail on fixture drift.
- `pnpm contract:check`: check generated types, every schema and fixture, canonical
  serialization, enabled-block coverage and wire-version consistency.

Inside this package, `pnpm generate` regenerates types and `pnpm check` checks them.
The producer also rejects any observed HTTP status absent from its OpenAPI operation.
Root `pnpm check` includes package checks; `pnpm test:integration` includes the
producer suite. CI runs both using the existing disposable WordPress 7.0 fixture.

The producer creates and removes a dedicated test template and its three parts.
It covers LTR, RTL, explicit language fallback, nesting, unsupported-node fallback,
manifest, discovery, tokens and icons (including their conditional 304s), preview create/read and
problem responses. Only changing
metadata (timestamps, revision IDs, preview tokens/URLs and correlation IDs) is
normalized after strict validation. Response fields and block payloads are retained.
The neutral block set (`fixtures/blocks/neutral.json`, `renderer: "neutral"`) is
extracted from returned layout nodes and covers every enabled manifest block,
including blocks whose optional provider is unavailable. Additional variant fixtures
are extracted from actual content REST responses, including populated/empty Social
Links and valid/invalid Video Hero media. It names no Site adapter.

Social Links nodes always carry `attributes.links`, a list of strict
`ResolvedSocialLink` records described by `social-link.schema.json`; the node
schema validates that shape conditionally by block name while other attribute
maps keep their extension point. The list is resolved from current site settings,
never trusted from block comments.

Site Logo nodes (`core/site-logo`) carry the Branding logos as strict
`ResolvedLogoImage` records (`site-logo-image.schema.json`) or `null`: `logo`,
`logoVariation` and `logoDark`. They are resolved when the layout is built, never
trusted from block comments. They remain optional fields in the schema; this producer always sends all
three. Their optionality does not allow a 1.x wire document. Render `logoDark` on dark surfaces, falling back to `logo` and then the
site title. `logoVariation` is a generic variation, never a Dark logo fallback.

The pattern schema is retained, but its former example is omitted: GQ Design has
no producer for that standalone logical-ID/translation document. A fixture should
be added when such a producer exists. The umbrella still includes its schema.

The package began with Ekis's unpublished `@getquick/design-contract` 0.1.8
(at ffe723f). Its commerce configuration and structured-data documents remain
owned outside this package. No source files in Ekis are changed by this move.

Logical IDs such as `template:contract-probe` and `part:contract-probe-header` are
portable identities; `sourceId` is diagnostic WordPress identity. Layouts describe
presentation and data requirements; private commerce facts belong to the Site's
commerce client.

## Product collection requests (contract 1.3.0)

GQ Design owns the wire envelope and validation. GQ eCommerce owns collection
selection, serialization and provider behavior; Sites own fetching and rendering.
The additive 1.3.0 contract retains key-only New Arrivals requests unchanged:
`{kind: "productCollection", key: "new-arrivals:tag:none"}` (or its existing tag ID key).
Do not reinterpret these as Featured Collections or require a query on them.

Featured Collections add `query` with exactly one selection and a required integer
`perPage` from 1 to 24:

- Hand-picked: `{productIds: [32, 11], perPage: 2}`. IDs are unique positive
  integers, at most 24; array order is merchant order.
- Category: `{categoryId: 7, perPage: 4}`. The ID is a positive integer.
- Explicit empty: `empty: true` with `{productIds: [], perPage: 4}` or
  `{categoryId: null, perPage: 4}`. Return no products and perform no unfiltered
  fallback. These empty selections require `empty: true`; nonempty selections
  allow `empty: false` or omission. `empty` alone is not a request.

Every request still requires `kind: "productCollection"` and a nonempty `key`
of at most 200 characters. Keys are opaque, deterministic provider identifiers;
consumers must use query metadata rather than parse Featured Collection keys.
The provider must bound/normalize IDs and page sizes and generate keys within
that limit. Product records stay outside public layout JSON. Consumers must
recheck product publication/visibility when fetching; cached IDs grant no access.

`fixtures/blocks/product-collections.json` contains normative provider examples,
including both explicit empty forms and legacy New Arrivals. These examples are
not captured REST output and do not enable a WooCommerce producer in GQ Design.
The existing schema loader and renderer validator build consume the node schema
automatically. Both strict producer validation and compatible consumer validation
are covered; unknown producer fields remain errors.

This additive wire revision ships in lockstep plugin/contract/renderer release
0.7.0. Do not republish 0.6.0 packages. GQ eCommerce
must raise its GQ Design runtime and Composer minimum to that released version
before shipping Featured Collections. Site consumers must adopt the matching
contract/renderer packages and handle explicit empties before enabling the feature.
