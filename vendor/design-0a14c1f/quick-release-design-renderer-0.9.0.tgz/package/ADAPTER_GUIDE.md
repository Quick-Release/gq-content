# Framework adapter guide

An adapter translates the framework-neutral GETQUICK Design contract into one
rendering runtime. Each commerce Site owns its React adapter. The shared renderer has no React dependency.
An adapter uses `@quick-release/design-contract` and
`@quick-release/design-renderer`; it must not read WordPress PHP or another Site's adapter. Render contract data rather than depending on WordPress frontend markup.

## Required responsibilities

### Contract boundary and traversal

Validate API JSON against the published JSON Schema at the network boundary, then
call `assertDesignLayout()` before rendering. Use `renderDesignLayout()` or
`walkDesignLayout()` so every framework observes the same header/content/footer
order, recursive child order, limits, and JSON Pointer paths. Treat `sourceId` as
diagnostic only; logical `template:*` and `part:*` IDs are portable.

### Node registry

Provide an explicit renderer for every block that the manifest marks `enabled`.
CI must call `validateManifestAdapter()` and fail on missing enabled renderers. A
wildcard renderer is suitable for tools and prototypes, but never satisfies
production manifest coverage.

The required `unknownNode` handler must be safe, deterministic, and visible to
telemetry. It must not execute arbitrary markup, scripts, shortcodes, or PHP.
Unknown and `supported: false` nodes should preserve safe child output when
possible, without pretending the missing component rendered successfully.

### Data requirements

Layout JSON includes composition and some resolved presentation data: navigation
items, Query item identities and pattern children, Branding logos, and Social Links
profiles. Consume those documented attributes directly. Query item IDs identify
content to render; they are not permission to expose private content or fetch
arbitrary database records.

Site Logo nodes carry `logo`, `logoVariation` and `logoDark` images or `null`.
Use `selectSiteLogo()` for the light/dark fallback from `logoDark` to `logo` to
the Site Title. It never substitutes `logoVariation`.

Other required route/domain data is supplied through `RendererEnvironment.data`.
Missing contexts produce `getquick_renderer_missing_context`; adapters should
render a bounded error or placeholder and report it without leaking private data.

### Composed core blocks

Grid preserves ordered Container children. Its shared `presentation` property
uses Base and upward breakpoint maps with explicit omission/reset rules.
Use `gridColumns` for layout tracks and `gap`, `rowGap`, `columnGap` independently
of spacing. No three/two/one device preset or implicit Grid gap is supplied.
Native Group, Columns/Column, Spacer and Separator expose relevant capabilities
in the same descriptor. Preserve native tag identities, authored unequal Column
widths and `isStackedOnMobile` when no neutral override applies. Native wrapper
selectors and Column width/flex-basis targets come from shared target metadata.
Use the published variables and complete stylesheet; source scanning arbitrary
runtime classes does not provide supported late-authored values.
Pass the complete block attributes as the third argument context:
`presentationVariables(node.name, node.attributes.presentation ?? {}, { attributes: node.attributes })`.
The shared descriptor resolves native Group Row/Stack/Grid display restoration
from its semantic layout mode. Editor wrappers additionally pass `editor: true`
so frontend-hidden content remains selectable. PHP `Presentation::variables()`
accepts the same complete attributes as its third argument. Do not independently
infer utility values in an adapter.
Container uses the shared neutral `attributes.presentation` model. `base` applies
at every width; `sm`, `md`, `lg`, `xl` and `2xl` override upward from the resolved
theme's breakpoints (defaults: 40rem, 48rem, 64rem, 80rem and 96rem). An omitted
property inherits from the preceding applicable level. Explicit `"auto"` is an
authored value; `"reset"` restores the property's declared initial value.

Use `presentationVariables(node.name, node.attributes.presentation)` on the
wrapper with its conventional WordPress block class and `gqd-presentation`, and
include the shared `presentationStyleSheet()` for the same resolved theme. Reuse
the shared descriptor's capabilities and values rather than adding a Site parser.
A bare Container supplies responsive caps without centering or padding. Width
and max width are independent; fractional widths and `"full"` are parent-relative,
while `"screen"` explicitly means viewport width. Centering uses
`marginInline: "auto"`; padding is separately authored. Native wide/full alignment
retains its containing layout's rules until an explicit presentation property
overrides them upward. The removed desktop/tablet/mobile sizing fields do not
participate in this model. See [Container presentation](../../docs/container-presentation.md)
for the extension interface and saved-document evidence.

Carousels preserve ordered Slider children and their separate Carousel Navigation
options. Query Loop keeps the stable `getquick-design/query` name, resolves its
selected items and supplies the item pattern once as children; the Site adapter
owns repeating that pattern with each item's content context. The retired
`getquick-design/loop` marker is unsupported and must remain visible to diagnostics.

Video Hero preserves nested accessible content over decorative media. Use the
shared presentation descriptor's wrapper, media and foreground targets: sizing
belongs to the wrapper, fit/focal position to media, and flex placement/text
alignment to the foreground. The foreground is a column flex layout; text
alignment remains independent of its placement. No viewport size or centering
is implied. The explicit media default is Cover.

Support validated self-hosted/YouTube sources and poster fallback. Media is
muted, looping, inline, unfocusable and decorative; nested content remains
accessible even without a valid source. Preserve a meaningful `iframeTitle`,
falling back to `Decorative background video` for an empty title. YouTube cover
uses the actual media box, never viewport approximations or iframe object-fit.
Import `videoHeroStyleSheet()` for canonical structural CSS,
`videoHeroFrameGeometry()` for framework-native geometry, or call
`mountVideoHero(heroElement)` from `./video-hero` after mounting the
canonical `.gqd-video-hero__media` and `.gqd-video-hero__content` structure. Its
cleanup function removes observers and pauses video. No DOM is accessed merely
by importing the module. Save iframe sources in `data-src` and omit video autoplay
until initialization; reduced motion must not start playback. The initializer
also responds to later preference changes. These media responsibilities apply
to structured Design, WPGraphQL Blocks and WordPress HTML consumers alike.

Social Links supplies the complete `attributes.links` list. No extra GraphQL
request is needed. Preserve order and accessible labels, use a custom icon URL
when present and the supplied SVG fallback otherwise, and render nothing for an
empty list. Custom icon images have empty alternative text; the link supplies its
accessible name. Validate URLs and treat SVG as data requiring an appropriate safe
rendering boundary. Preserve the block's native wrapper/style options.

### Tokens

Resolve semantic token/value pairs through `resolveToken`; the shared
`resolveDesignToken` handles WordPress preset references and dotted token names. Each platform owns its
mapping to CSS variables, native styles, design-system values, or another styling
mechanism. Never expose Tailwind classes, React props, or platform component names
in the public contract. Unknown tokens must degrade to an explicit safe default.

### Links

Blocks with link-like attributes must call the environment's `resolveLink` boundary.
The adapter owns URL policy, locale-aware internal routing, external-link behavior,
targets, rel values, and navigation APIs. Never pass an unvalidated contract string
directly to a navigation primitive.

### Language and direction

Use `layout.language.resolved` for the rendered language and
`layout.language.direction` for `ltr`/`rtl`. Preserve the requested/resolved fallback
state for diagnostics. Canonical and alternate URLs come from API response `Link`
headers or the route loader, not from WordPress implementation IDs.

### Errors and diagnostics

`RendererContractError` means the response cannot be safely traversed and must stop
rendering at the route boundary. `RenderIssue` describes a recoverable adapter,
manifest, unknown-node, or missing-context condition. Send issues through
`onIssue`, then let framework-specific error boundaries decide presentation.
Correlation and observability transport remain outside renderer core.

## Minimal non-React adapter

```ts
const adapter = {
  nodes: {
    "core/paragraph": ({ node }) => ({ kind: "text", value: node.content }),
  },
  unknownNode: ({ node, children }) => ({
    kind: "unknown",
    name: node.name,
    children,
  }),
  region: ({ region, children }) => ({
    kind: "region",
    slot: region.slot,
    children,
  }),
  layout: ({ layout, regions }) => ({
    kind: "layout",
    language: layout.language.resolved,
    children: regions,
  }),
};

const tree = renderDesignLayout(layout, adapter, {
  context: {},
  data: { site },
  resolveToken: (token, value) => tokenMap[token]?.[value],
  resolveLink: (value) => safeUrl(value),
  onIssue: (issue) => report(issue),
});
```

The returned value can be consumed by Vue, Svelte, native mobile, a server-side
template engine, a static generator, or a test harness without changing WordPress
serialization.

## Reference scope

`@quick-release/design-renderer/reference` exports `renderReferenceHtml` and its
explicit `referenceAdapter` registry. It produces escaped diagnostic metadata and
children, not a storefront UI. Its contract-fixture tests do not prove a Site's grid
breakpoints, video behavior, social presentation, Query repetition or carousel
interaction. Verify those in the Site-owned adapter.

## Run the pinned contract in Site CI

Import `assertRegistryCoverage` and `assertFixtureRendering` from
`@quick-release/design-renderer/testing`. Both work with any test runner and throw
`RendererTestError` containing actionable failures. Keep the contract and renderer
packages pinned together.

```ts
assertRegistryCoverage(adapter, { siteBlocks: siteManifestAdditions });
assertFixtureRendering(
  adapter,
  {
    context: adapterFixtureContext,
    data: routeFixtureData,
    resolveToken: resolveDesignToken,
    resolveLink: safeFixtureLink,
    onIssue: reportFixtureIssue,
  },
  {
    siteBlocks: siteManifestAdditions,
    additionalFixtures: siteFixtures,
  },
);
```

Supply only Site-added manifest entries (`name` and `enabled`) rather than a copy
of the core manifest. They append required enabled names without changing core
requirements. Extra registry names are allowed; a wildcard does not satisfy
coverage. All producer-neutral fixture variants always run. Additional Site
fixtures append `{ fixture, node }` cases and should exercise composed children and
Site-specific data requirements. Provide the domain contexts and resolvers your
adapter actually needs; missing data, fallback and exceptions fail the check.

Each fixture runs in an isolated content region with otherwise empty regions, so
these are portable block checks rather than route-specific integration fixtures.
Reported failures include the fixture identifier and JSON Pointer. Add Site tests
for route behavior, loading, repetition, accessibility and interaction.

Every enabled Site addition requires an additional neutral fixture whose root
node has that block name. A renderer entry alone does not satisfy fixture coverage.

Site-owned blocks can reuse the canonical presentation compiler with explicit
capabilities, without defining new values or changing core block capabilities:

```ts
const model = createPresentationModel({
  "site/card": {
    properties: ["paddingInline", "width"],
    selector: ".site-card",
    targets: { width: " > .site-card__image" },
  },
});
const variables = presentationVariables("site/card", node.attributes.presentation, { model });
const css = presentationStyleSheet(resolvedSiteTheme, { model });
```

Import these functions from `@quick-release/design-renderer`. Supply the same
model to both helpers. Properties must already exist in the shared catalog.
Selectors are bounded to one wrapper class and descendant/child class paths;
selector lists, global selectors and raw CSS declarations are rejected. Omission
adds no implicit styling defaults to Site blocks. Include the generated CSS in
the production build, then verify computed presentation in the real Site adapter.
Declaring presentation capabilities does not enable a block in the Design catalog.

### Typography, lists and Buttons

Text-family nodes expose `attributes.presentation` through the shared property
catalog. Use `presentationVariables()` and `presentationStyleSheet()` with the
resolved Site theme; the contract stores structured values, never utility classes.
`color` and `backgroundColor` accept exactly one of `{ palette: "foreground" }`,
`{ theme: "red-500" }` or `{ literal: "oklch(70% 0.1 200)" }`. Palette references
retain their Site identity. `fontFamily` uses `{ theme: "sans" }`; a Site can
explicitly override that theme family. Omission inherits upward; `reset` is an
explicit authored value. The descriptor supplies the reset for each property.

A named `fontSize` applies its theme size and matching default line height. An
explicit `lineHeight` overrides that companion value independently, including
across breakpoints. Keep heading `level`, Site/Post title linking, and Post Content
resolution separate from typography. `textAlign: "start"` and `"end"` follow the
rendered reading direction and do not position the wrapper.

Use the shared descriptor's native selectors and element targets in HTML adapters.
Buttons lays out its child Buttons with direction, wrap, gap, main-axis and
cross-axis controls. Individual Button typography, background, padding and radius
apply to its link; its outer margins apply to the wrapper. Retain URL handling,
target, rel, accessible name and keyboard focus behavior.

Heading and Paragraph expose sanitized inline rich text as string
`attributes.content`, extracted from their native saved element with the shared
WordPress HTML token parser and KSES boundary. Render this inline value inside the
consumer's semantic heading/paragraph element to preserve links, strong text and
spans. Heading `level` and full-wrapper `node.content` remain available. Do not
parse `node.content` in each Site adapter to recover the inline value.

Lists start without markers under Preflight. An author can request `listStyleType`
(`none`, `disc`, `decimal`) and `listStylePosition` independently of semantic
`ordered`, `start` and `reversed` attributes. List Item's sanitized rich text is
available as `attributes.content`, including when it has nested List children.
Render that rich text before its ordered children; non-leaf `node.content` is
otherwise null. Preserve the child tree rather than recovering it from HTML.

This is a breaking presentation change. These producer and shared-renderer
interfaces do not establish parity in a production Site adapter; each consumer
must exercise the saved-document fixtures and its own computed CSS and interactions.

In WordPress, add the same declaration as `presentation` on a Site-owned
`getquick_design_block_definitions` entry with `source: "site"`, `enabled: true`
and a nonempty `renderer_fixture`. The manifest returns it as `presentationExtension`.
Declare `defaultDisplay` (for example `"flex"` or `"grid"`) when the native wrapper
uses a mode other than block. The shared bounded display vocabulary restores this
mode for responsive `auto`/`reset` and the editor's hidden-content preview.
The shared PHP value parser, editor controls and generated frontend CSS use these
declarations. Disabled and registered-only blocks gain no capabilities. This
does not make arbitrary Site blocks writable through agent authoring: writable
blocks still require verified Gutenberg serialization in the closed catalog.

## Navigation presentation

Navigation, its approved native children, Social Links and the conditionally
registered Polylang language switcher use `attributes.presentation` with the
shared `presentationModel`. Use its per-block capabilities and targets, with
`presentationVariables()` and `presentationStyleSheet()`; do not recover values
from utility class names. Wrapper spacing and display are independent of the
navigation list's flex direction, wrapping, gap, justify content and align items.
Text alignment uses logical start/end independently of wrapper placement.

Native Navigation delivers its published, language-resolved reference as
`children` as well as its resolved `attributes.items`. Render one composition,
not both copies. Prefer the child tree when styling link/submenu/page-list
wrappers. A page-list child carries resolved `attributes.items`; a page-list item
with dynamically resolved descendants includes them as child nodes. Menu items also
retain their own validated `presentation`. Source trees are bounded and contain
only approved native navigation children. Keep link resolution, submenu toggles,
keyboard focus, current state and overlays in component behavior. The overlay
boundary is the resolved theme's `lg`, including explicit Site overrides.

The existing `polylang/language-switcher` remains conditional on both multilingual
support and actual block registration. Its attributes retain `dropdown`,
`show_names`, `show_flags`, `force_home`, `hide_current` and
`hide_if_no_translation`. Resolved `links` contain `slug`, `locale`, `label`,
`url`, `flagUrl`, `current`, `direction` and `noTranslation`. Preserve order and
use the label as the accessible name even when only flags are visible. Flag URLs
are data, not SVG/HTML fragments. Empty links render nothing. A dropdown retains
its current option and keyboard operation. Route-specific alternate links still
require the route context described above; fixture coverage of home links is
not proof of every translated route.

These are breaking presentation semantics. Bare custom navigation and social
lists no longer add implicit wrapping, centered cross-axis alignment or gaps.
Editors preview the resolved menu/profile content rather than a placeholder.
Every affected Site adapter and HTML consumer needs its own production rendering
checks; the diagnostic reference renderer does not establish acceptance.

## Resolved theme and reset (breaking adoption)

Read `tokens.theme` (REST) or `designTokens { theme }` (the GraphQL
`DesignResolvedTheme` JSON scalar). Both carry the same complete neutral
configuration. They include the five upward breakpoints, spacing unit, colors,
font families/sizes/paired line heights/weights, line heights, letter spacings,
radii and named maximum widths. Semantic palette identities and reviewed dark
support remain in `tokens.colors` and `darkSchemeEnabled`; theme colors do not
replace them or enable dark support.

Use the shared implementation rather than another default table:

```ts
import {
  resolveDesignTheme,
  designThemeStyleSheet,
  presentationStyleSheet,
} from "@quick-release/design-renderer";

const theme = resolveDesignTheme(tokens.theme);
const css = designThemeStyleSheet(theme, ".gqd-content") + presentationStyleSheet(theme);
```

Place every rendered Design region within that root. Preflight resets headings,
list markers, borders and media defaults there; authored presentation remains
explicit. Use a separate root for each content region when the surrounding app
must keep its own defaults. The theme emitter accepts one simple class selector
or `:root`, never arbitrary selector strings. Do not scope it to wp-admin or
inspector roots.

Theme values become `--gqd-spacing`, `--gqd-color-*`, `--gqd-font-*`,
`--gqd-text-*` (plus `--gqd-text-*--line-height`), `--gqd-font-weight-*`,
`--gqd-leading-*`, `--gqd-tracking-*`, `--gqd-radius-*`, `--gqd-container-*`
and `--gqd-breakpoint-*`. Numeric spacing values inherit the root spacing unit;
literal `px` retains its physical size. `property.themeToken` uses the singular
CSS namespace, for example `radius` or `container`. The property compiler owns
all mappings, targets and upward inheritance.

Regenerate **both** style strings whenever the resolved theme changes. Runtime
color variables alone cannot change media queries. Include the resolved theme
in frontend cache/build identity; public token ETags already include it. Do not
rebuild once per CMS document: all finite exposed settings use complete static
rules and validated per-block variables, including documents first authored
after the production CSS build.

The common parser supports `valueType: "color"` values `{palette: "accent"}`,
`{theme: "red-500"}` and `{literal: "oklch(60% 0.2 20)"}`, and `valueType:
"font"` values `{theme: "sans"}`. These are neutral references, never class
strings. Site font overrides can replace the `sans`, `serif` or `mono` family
stacks; existing GraphQL font-face delivery remains separate. Safe color
validation is shared with palette delivery and dark counterparts. Contrast
checks still report unsupported non-hex formats instead of inventing a ratio;
review acknowledgement and dark enablement retain their established meaning.

Native Columns retain semantic `isStackedOnMobile`, `verticalAlignment`, and
Column `width`/`verticalAlignment` attributes. Pass complete attributes to
`presentationVariables` and preserve the core `is-not-stacked-on-mobile` class
when stacking is disabled. Native Column percentage widths project to inline
`flex-basis`. The canonical descriptor supplies equal growth, alignment, and
the native 782px stacking boundary; adapters do not supply another layout policy.
Explicit neutral presentation overrides these structural baselines.
